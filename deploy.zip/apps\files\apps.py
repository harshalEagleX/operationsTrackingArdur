from django.apps import AppConfig


class FilesConfig(AppConfig):
    name = "apps.files"
    label = "files"
    verbose_name = "Files"
