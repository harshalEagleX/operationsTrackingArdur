from django.apps import AppConfig


class SettingsAppConfig(AppConfig):
    name = "apps.settings_app"
    label = "settings_app"
    verbose_name = "Application settings"
